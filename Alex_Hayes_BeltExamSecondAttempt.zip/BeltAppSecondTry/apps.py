from django.apps import AppConfig


class BeltappsecondtryConfig(AppConfig):
    name = 'BeltAppSecondTry'
